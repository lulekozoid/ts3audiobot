#!/bin/bash

clear

# Config #

Interval='3'

# Variable #

Author='XaNeZ.pl'
FanPage='XaNeZ.pl/FanPage.php'
TeamSpeak='FlameSpeak.pl'
Prefix=':::'
Space='### ### ### ### ### ### ### ### ### ###'
Empty='	'
pKFnJL='\033[0m'
mhcmL5='\033[0;32m'
HHmXgB='\033[0;31m'
Ymc7yH='\033[1;30m'

# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- #

sleep 1
echo -e $Empty
echo -e $Ymc7yH$Space$pKFnJL
echo -e $mhcmL5$Prefix$pKFnJL 'Hello - TS3AudioBot.sh.'
echo -e $mhcmL5$Prefix$pKFnJL 'The Start.sh Process...'
echo -e $Ymc7yH$Space$pKFnJL
echo -e $Empty
echo -e $pKFnJL   'Select' $HHmXgB'1.' $pKFnJL'to Start one Screen or Select' $HHmXgB'2.' $pKFnJL'to Start several Screen.'
echo -e $Empty
echo -e '...'
echo -e $Empty
read Number
if [ $Number = 1 ]
then
	clear
	sleep 1
	echo -e $Empty
	echo -e $mhcmL5$Prefix$pKFnJL 'Enter the Screen Number...'
	echo -e $Empty
	read StdpZT
	clear
	sleep 1
	echo -e $Empty
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $mhcmL5$Prefix$pKFnJL 'System - A request has been Accepted...'
	echo -e $Empty
	echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $Empty
	sleep 6
	clear
	if screen -ls | grep TS3AudioBot$StdpZT;
	then
		clear
		echo -e $Empty
		echo -e '...'
		echo -e $Empty
	else
		clear
		cd /home/TS3AudioBot
		screen -AdmS TS3AudioBot$StdpZT mono TS3AudioBot.exe -c /home/TS3AudioBot/config/$StdpZT.cfg
	fi
	clear
	sleep 1
	echo -e $Empty
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $mhcmL5$Prefix$pKFnJL 'System - A request has been Processed...'
	echo -e $Empty
	echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $Empty
	sleep 6
	clear
elif [ $Number = 2 ]
then
	clear
	sleep 1
	echo -e $Empty
	echo -e $mhcmL5$Prefix$pKFnJL 'System - Enter a Value, e.g. 1, 3, 10...'
	echo -e $Empty
	read HCz5cX
	if (( $HCz5cX < 513 ))
	then
		clear
		sleep 1
		echo -e $Empty
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $mhcmL5$Prefix$pKFnJL 'System - A request has been Accepted...'
		echo -e $Empty
		echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $Empty
		sleep 6
		clear
		for (( kYXHzT=1; $kYXHzT <=$HCz5cX; kYXHzT++ ));
		do
		  if screen -ls | grep TS3AudioBot$kYXHzT;
		  then
			  clear
			  echo -e $Empty
			  echo -e '...'
			  echo -e $Empty
		  else
			  clear
			  cd /home/TS3AudioBot
			  screen -AdmS TS3AudioBot$kYXHzT mono TS3AudioBot.exe -c /home/TS3AudioBot/config/$kYXHzT.cfg
			  sleep $Interval
		  fi
		done
		clear
		sleep 1
		echo -e $Empty
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $mhcmL5$Prefix$pKFnJL 'System - A request has been Processed...'
		echo -e $Empty
		echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $Empty
		sleep 6
		clear
	elif (( $HCz5cX > 512 ))
	then
		clear
		sleep 1
		echo -e $Empty
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $HHmXgB$Prefix$pKFnJL 'System - A request has been Rejected...'
		echo -e $Empty
		echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
		echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
		echo -e $Ymc7yH$Space$pKFnJL
		echo -e $Empty
		sleep 6
		clear
	fi
elif (( $Number > 2 ))
then
	clear
	sleep 1
	echo -e $Empty
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $HHmXgB$Prefix$pKFnJL 'System - A request has been Rejected...'
	echo -e $Empty
	echo -e $HHmXgB$Prefix$pKFnJL 'Author,' $mhcmL5$Author$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'FanPage,' $mhcmL5$FanPage$pKFnJL'.'
	echo -e $HHmXgB$Prefix$pKFnJL 'TeamSpeak,' $mhcmL5$TeamSpeak$pKFnJL'.'
	echo -e $Ymc7yH$Space$pKFnJL
	echo -e $Empty
	sleep 6
	clear
fi

# --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- #